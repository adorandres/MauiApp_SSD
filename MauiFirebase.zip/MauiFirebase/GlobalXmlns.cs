[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "MauiFirebase")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "MauiFirebase.Pages")]
